from django.utils.translation import ugettext_lazy as _

ROLES = (
    (1, _('Cashier')),
    (2, _('Barista')),
    (3, _('Manager')),
    (4, _('Owner')),
)
